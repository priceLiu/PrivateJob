//---------------------------------------------
// Example program to test The FileSystemWatcher component.
//FileWatcher. This application allows you to monitor file open, close,
//create and changes to all files.
// Bill Nolde 2002
// billnolde@ieee.org

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Runtime.InteropServices;


namespace FileWatch
{
	
	public class Form1 : System.Windows.Forms.Form
	{
		[DllImport("user32.dll")]
		public static extern bool  MessageBeep(int Sound);
		[DllImport("user32.dll")]
		public static extern int   MessageBox(int hWnd, String text, 
			String caption, uint type);
		
		public FileSystemWatcher watcher;
		public string[] m_textFilters;// Arry to hold filter supplied by txtTextFilter coltrol
        //{{{
        //FileSystemWatcher[] fsWatcherList = new FileSystemWatcher[20];
       // int fsWatcherCount = 0;
        //}}}
        private System.IO.FileSystemWatcher fileSystemWatcher1;
		private System.Windows.Forms.Button ExitButton;
		private System.Windows.Forms.TextBox m_starting_path;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button mStopButton;
		private System.Windows.Forms.Button mStartButton;
		private System.Windows.Forms.FolderBrowserDialog folderBrowse;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.Button btnFolderBrowse;
		private System.Windows.Forms.Button btnSaveLog;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ListBox lstCreatedFilesFiles;
		private System.Windows.Forms.Label lblCreated;
        private System.Windows.Forms.Label lblDeleted;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label lblChanged;
		private System.Windows.Forms.Label lblRenamed;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabCreatedFiles;
		private System.Windows.Forms.TabPage tabDeletedFiles;
		private System.Windows.Forms.TabPage tabChangedFiles;
		private System.Windows.Forms.TabPage tabRenameFiles;
		private System.Windows.Forms.TabPage ExcludedFiles;
		private System.Windows.Forms.ListBox lstExclude;
		private System.Windows.Forms.ListBox lstCreatedFiles;
		private System.Windows.Forms.ListBox lstRenameFiles;
		private System.Windows.Forms.ListBox lstChangedFiles;
		private System.Windows.Forms.ListBox lstDeletedFiles;
		private System.Windows.Forms.Button btnClearList;
		private System.Windows.Forms.Button btnLoadExcludeFile;
		private System.Windows.Forms.TabPage txtSettings;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox txtTextFilter;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.CheckBox cb_subdirectory;
		private System.Windows.Forms.CheckBox cb_created;
		private System.Windows.Forms.CheckBox cb_deleted;
		public System.Windows.Forms.CheckBox cb_renamed;
		private System.Windows.Forms.CheckBox cb_changed;
		private System.Windows.Forms.ComboBox m_filter;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.NotifyIcon notifyIcon1;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			m_starting_path.Text = "C:\\Temp";
			watcher = new FileSystemWatcher();
		}
		public bool isExcluded(string txt)
		{
			return true;
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.ExitButton = new System.Windows.Forms.Button();
            this.mStartButton = new System.Windows.Forms.Button();
            this.m_starting_path = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.mStopButton = new System.Windows.Forms.Button();
            this.folderBrowse = new System.Windows.Forms.FolderBrowserDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.btnFolderBrowse = new System.Windows.Forms.Button();
            this.btnSaveLog = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCreated = new System.Windows.Forms.Label();
            this.lblDeleted = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblChanged = new System.Windows.Forms.Label();
            this.lblRenamed = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabCreatedFiles = new System.Windows.Forms.TabPage();
            this.lstCreatedFiles = new System.Windows.Forms.ListBox();
            this.tabChangedFiles = new System.Windows.Forms.TabPage();
            this.lstChangedFiles = new System.Windows.Forms.ListBox();
            this.tabDeletedFiles = new System.Windows.Forms.TabPage();
            this.lstDeletedFiles = new System.Windows.Forms.ListBox();
            this.tabRenameFiles = new System.Windows.Forms.TabPage();
            this.lstRenameFiles = new System.Windows.Forms.ListBox();
            this.ExcludedFiles = new System.Windows.Forms.TabPage();
            this.btnClearList = new System.Windows.Forms.Button();
            this.btnLoadExcludeFile = new System.Windows.Forms.Button();
            this.lstExclude = new System.Windows.Forms.ListBox();
            this.txtSettings = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTextFilter = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_subdirectory = new System.Windows.Forms.CheckBox();
            this.cb_created = new System.Windows.Forms.CheckBox();
            this.cb_deleted = new System.Windows.Forms.CheckBox();
            this.cb_renamed = new System.Windows.Forms.CheckBox();
            this.cb_changed = new System.Windows.Forms.CheckBox();
            this.m_filter = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.menuItem6 = new System.Windows.Forms.MenuItem();
            this.menuItem5 = new System.Windows.Forms.MenuItem();
            this.menuItem8 = new System.Windows.Forms.MenuItem();
            this.menuItem9 = new System.Windows.Forms.MenuItem();
            this.menuItem10 = new System.Windows.Forms.MenuItem();
            this.menuItem11 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.menuItem7 = new System.Windows.Forms.MenuItem();
            this.menuItem12 = new System.Windows.Forms.MenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabCreatedFiles.SuspendLayout();
            this.tabChangedFiles.SuspendLayout();
            this.tabDeletedFiles.SuspendLayout();
            this.tabRenameFiles.SuspendLayout();
            this.ExcludedFiles.SuspendLayout();
            this.txtSettings.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(8, 56);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(80, 24);
            this.ExitButton.TabIndex = 0;
            this.ExitButton.Text = "Exit";
            this.ExitButton.Click += new System.EventHandler(this.ExitButtonClick);
            // 
            // mStartButton
            // 
            this.mStartButton.Location = new System.Drawing.Point(8, 24);
            this.mStartButton.Name = "mStartButton";
            this.mStartButton.Size = new System.Drawing.Size(80, 24);
            this.mStartButton.TabIndex = 1;
            this.mStartButton.Text = "Start";
            this.mStartButton.Click += new System.EventHandler(this.StartButtonClick);
            // 
            // m_starting_path
            // 
            this.m_starting_path.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.m_starting_path.Location = new System.Drawing.Point(96, 8);
            this.m_starting_path.Name = "m_starting_path";
            this.m_starting_path.Size = new System.Drawing.Size(312, 20);
            this.m_starting_path.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Watch Folder";
            // 
            // mStopButton
            // 
            this.mStopButton.Enabled = false;
            this.mStopButton.Location = new System.Drawing.Point(120, 24);
            this.mStopButton.Name = "mStopButton";
            this.mStopButton.Size = new System.Drawing.Size(80, 24);
            this.mStopButton.TabIndex = 11;
            this.mStopButton.Text = "Stop";
            this.mStopButton.Click += new System.EventHandler(this.mStopButton_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "TextFile(*.txt)|*.txt";
            // 
            // btnFolderBrowse
            // 
            this.btnFolderBrowse.Location = new System.Drawing.Point(416, 8);
            this.btnFolderBrowse.Name = "btnFolderBrowse";
            this.btnFolderBrowse.Size = new System.Drawing.Size(32, 20);
            this.btnFolderBrowse.TabIndex = 14;
            this.btnFolderBrowse.Text = "...";
            this.btnFolderBrowse.Click += new System.EventHandler(this.btnFolderBrowse_Click);
            // 
            // btnSaveLog
            // 
            this.btnSaveLog.Location = new System.Drawing.Point(120, 56);
            this.btnSaveLog.Name = "btnSaveLog";
            this.btnSaveLog.Size = new System.Drawing.Size(80, 24);
            this.btnSaveLog.TabIndex = 15;
            this.btnSaveLog.Text = "Save Log";
            this.btnSaveLog.Click += new System.EventHandler(this.btnSaveLog_Click);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(16, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 19;
            this.label4.Text = "Deteted Files";
            // 
            // lblCreated
            // 
            this.lblCreated.Location = new System.Drawing.Point(104, 16);
            this.lblCreated.Name = "lblCreated";
            this.lblCreated.Size = new System.Drawing.Size(72, 16);
            this.lblCreated.TabIndex = 29;
            // 
            // lblDeleted
            // 
            this.lblDeleted.Location = new System.Drawing.Point(104, 32);
            this.lblDeleted.Name = "lblDeleted";
            this.lblDeleted.Size = new System.Drawing.Size(72, 16);
            this.lblDeleted.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(16, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 16);
            this.label5.TabIndex = 22;
            this.label5.Text = "Changed";
            // 
            // lblChanged
            // 
            this.lblChanged.Location = new System.Drawing.Point(104, 48);
            this.lblChanged.Name = "lblChanged";
            this.lblChanged.Size = new System.Drawing.Size(72, 16);
            this.lblChanged.TabIndex = 31;
            // 
            // lblRenamed
            // 
            this.lblRenamed.Location = new System.Drawing.Point(104, 64);
            this.lblRenamed.Name = "lblRenamed";
            this.lblRenamed.Size = new System.Drawing.Size(72, 16);
            this.lblRenamed.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(16, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 16);
            this.label6.TabIndex = 23;
            this.label6.Text = "Renamed";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(16, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 16);
            this.label3.TabIndex = 18;
            this.label3.Text = "Created Files";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabCreatedFiles);
            this.tabControl1.Controls.Add(this.tabChangedFiles);
            this.tabControl1.Controls.Add(this.tabDeletedFiles);
            this.tabControl1.Controls.Add(this.tabRenameFiles);
            this.tabControl1.Controls.Add(this.ExcludedFiles);
            this.tabControl1.Controls.Add(this.txtSettings);
            this.tabControl1.ItemSize = new System.Drawing.Size(0, 18);
            this.tabControl1.Location = new System.Drawing.Point(8, 64);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(448, 224);
            this.tabControl1.TabIndex = 38;
            // 
            // tabCreatedFiles
            // 
            this.tabCreatedFiles.Controls.Add(this.lstCreatedFiles);
            this.tabCreatedFiles.Location = new System.Drawing.Point(4, 22);
            this.tabCreatedFiles.Name = "tabCreatedFiles";
            this.tabCreatedFiles.Size = new System.Drawing.Size(440, 198);
            this.tabCreatedFiles.TabIndex = 0;
            this.tabCreatedFiles.Text = "Created Files";
            // 
            // lstCreatedFiles
            // 
            this.lstCreatedFiles.HorizontalScrollbar = true;
            this.lstCreatedFiles.Location = new System.Drawing.Point(0, 0);
            this.lstCreatedFiles.Name = "lstCreatedFiles";
            this.lstCreatedFiles.ScrollAlwaysVisible = true;
            this.lstCreatedFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstCreatedFiles.Size = new System.Drawing.Size(440, 199);
            this.lstCreatedFiles.TabIndex = 25;
            // 
            // tabChangedFiles
            // 
            this.tabChangedFiles.Controls.Add(this.lstChangedFiles);
            this.tabChangedFiles.Location = new System.Drawing.Point(4, 22);
            this.tabChangedFiles.Name = "tabChangedFiles";
            this.tabChangedFiles.Size = new System.Drawing.Size(440, 198);
            this.tabChangedFiles.TabIndex = 2;
            this.tabChangedFiles.Text = "ChangedFiles";
            // 
            // lstChangedFiles
            // 
            this.lstChangedFiles.HorizontalScrollbar = true;
            this.lstChangedFiles.Location = new System.Drawing.Point(0, 0);
            this.lstChangedFiles.Name = "lstChangedFiles";
            this.lstChangedFiles.ScrollAlwaysVisible = true;
            this.lstChangedFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstChangedFiles.Size = new System.Drawing.Size(440, 199);
            this.lstChangedFiles.TabIndex = 0;
            this.lstChangedFiles.DoubleClick += new System.EventHandler(this.lstChangedFiles_DoubleClick_1);
            this.lstChangedFiles.SelectedIndexChanged += new System.EventHandler(this.lstChangedFiles_SelectedIndexChanged);
            // 
            // tabDeletedFiles
            // 
            this.tabDeletedFiles.Controls.Add(this.lstDeletedFiles);
            this.tabDeletedFiles.Location = new System.Drawing.Point(4, 22);
            this.tabDeletedFiles.Name = "tabDeletedFiles";
            this.tabDeletedFiles.Size = new System.Drawing.Size(440, 198);
            this.tabDeletedFiles.TabIndex = 1;
            this.tabDeletedFiles.Text = "DeletedFiles";
            // 
            // lstDeletedFiles
            // 
            this.lstDeletedFiles.HorizontalScrollbar = true;
            this.lstDeletedFiles.Location = new System.Drawing.Point(0, 0);
            this.lstDeletedFiles.Name = "lstDeletedFiles";
            this.lstDeletedFiles.ScrollAlwaysVisible = true;
            this.lstDeletedFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstDeletedFiles.Size = new System.Drawing.Size(440, 199);
            this.lstDeletedFiles.TabIndex = 18;
            this.lstDeletedFiles.SelectedIndexChanged += new System.EventHandler(this.lstDeletedFiles_SelectedIndexChanged);
            // 
            // tabRenameFiles
            // 
            this.tabRenameFiles.Controls.Add(this.lstRenameFiles);
            this.tabRenameFiles.Location = new System.Drawing.Point(4, 22);
            this.tabRenameFiles.Name = "tabRenameFiles";
            this.tabRenameFiles.Size = new System.Drawing.Size(440, 198);
            this.tabRenameFiles.TabIndex = 3;
            this.tabRenameFiles.Text = "RenameFiles";
            // 
            // lstRenameFiles
            // 
            this.lstRenameFiles.HorizontalScrollbar = true;
            this.lstRenameFiles.Location = new System.Drawing.Point(0, 0);
            this.lstRenameFiles.Name = "lstRenameFiles";
            this.lstRenameFiles.ScrollAlwaysVisible = true;
            this.lstRenameFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstRenameFiles.Size = new System.Drawing.Size(440, 199);
            this.lstRenameFiles.TabIndex = 22;
            // 
            // ExcludedFiles
            // 
            this.ExcludedFiles.Controls.Add(this.btnClearList);
            this.ExcludedFiles.Controls.Add(this.btnLoadExcludeFile);
            this.ExcludedFiles.Controls.Add(this.lstExclude);
            this.ExcludedFiles.Location = new System.Drawing.Point(4, 22);
            this.ExcludedFiles.Name = "ExcludedFiles";
            this.ExcludedFiles.Size = new System.Drawing.Size(440, 198);
            this.ExcludedFiles.TabIndex = 4;
            this.ExcludedFiles.Text = "ExcludedFiles";
            // 
            // btnClearList
            // 
            this.btnClearList.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearList.Location = new System.Drawing.Point(312, 168);
            this.btnClearList.Name = "btnClearList";
            this.btnClearList.Size = new System.Drawing.Size(112, 24);
            this.btnClearList.TabIndex = 30;
            this.btnClearList.Text = "Clear List";
            this.btnClearList.Click += new System.EventHandler(this.btnClearList_Click_1);
            // 
            // btnLoadExcludeFile
            // 
            this.btnLoadExcludeFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadExcludeFile.Location = new System.Drawing.Point(200, 168);
            this.btnLoadExcludeFile.Name = "btnLoadExcludeFile";
            this.btnLoadExcludeFile.Size = new System.Drawing.Size(112, 24);
            this.btnLoadExcludeFile.TabIndex = 29;
            this.btnLoadExcludeFile.Text = "Load Ex File List";
            this.btnLoadExcludeFile.Click += new System.EventHandler(this.btnLoadExcludeFile_Click_1);
            // 
            // lstExclude
            // 
            this.lstExclude.HorizontalScrollbar = true;
            this.lstExclude.Location = new System.Drawing.Point(0, 8);
            this.lstExclude.Name = "lstExclude";
            this.lstExclude.ScrollAlwaysVisible = true;
            this.lstExclude.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstExclude.Size = new System.Drawing.Size(432, 147);
            this.lstExclude.TabIndex = 26;
            // 
            // txtSettings
            // 
            this.txtSettings.Controls.Add(this.groupBox1);
            this.txtSettings.Location = new System.Drawing.Point(4, 22);
            this.txtSettings.Name = "txtSettings";
            this.txtSettings.Size = new System.Drawing.Size(440, 198);
            this.txtSettings.TabIndex = 5;
            this.txtSettings.Text = "Settings";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtTextFilter);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cb_subdirectory);
            this.groupBox1.Controls.Add(this.cb_created);
            this.groupBox1.Controls.Add(this.cb_deleted);
            this.groupBox1.Controls.Add(this.cb_renamed);
            this.groupBox1.Controls.Add(this.cb_changed);
            this.groupBox1.Controls.Add(this.m_filter);
            this.groupBox1.Location = new System.Drawing.Point(32, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 128);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(176, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 16);
            this.label9.TabIndex = 39;
            this.label9.Text = "Text Filter";
            // 
            // txtTextFilter
            // 
            this.txtTextFilter.Location = new System.Drawing.Point(176, 96);
            this.txtTextFilter.Name = "txtTextFilter";
            this.txtTextFilter.Size = new System.Drawing.Size(160, 20);
            this.txtTextFilter.TabIndex = 38;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(16, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 14);
            this.label2.TabIndex = 19;
            this.label2.Text = "File Type";
            // 
            // cb_subdirectory
            // 
            this.cb_subdirectory.Checked = true;
            this.cb_subdirectory.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_subdirectory.Location = new System.Drawing.Point(16, 16);
            this.cb_subdirectory.Name = "cb_subdirectory";
            this.cb_subdirectory.Size = new System.Drawing.Size(136, 21);
            this.cb_subdirectory.TabIndex = 17;
            this.cb_subdirectory.Text = "Include Subdirectories";
            // 
            // cb_created
            // 
            this.cb_created.Checked = true;
            this.cb_created.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_created.Location = new System.Drawing.Point(176, 48);
            this.cb_created.Name = "cb_created";
            this.cb_created.Size = new System.Drawing.Size(64, 20);
            this.cb_created.TabIndex = 16;
            this.cb_created.Text = "created";
            // 
            // cb_deleted
            // 
            this.cb_deleted.Checked = true;
            this.cb_deleted.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_deleted.Location = new System.Drawing.Point(248, 48);
            this.cb_deleted.Name = "cb_deleted";
            this.cb_deleted.Size = new System.Drawing.Size(87, 21);
            this.cb_deleted.TabIndex = 15;
            this.cb_deleted.Text = "Deleted";
            // 
            // cb_renamed
            // 
            this.cb_renamed.Checked = true;
            this.cb_renamed.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_renamed.Location = new System.Drawing.Point(96, 48);
            this.cb_renamed.Name = "cb_renamed";
            this.cb_renamed.Size = new System.Drawing.Size(87, 20);
            this.cb_renamed.TabIndex = 14;
            this.cb_renamed.Text = "Renamed";
            // 
            // cb_changed
            // 
            this.cb_changed.Checked = true;
            this.cb_changed.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_changed.Location = new System.Drawing.Point(16, 48);
            this.cb_changed.Name = "cb_changed";
            this.cb_changed.Size = new System.Drawing.Size(87, 21);
            this.cb_changed.TabIndex = 13;
            this.cb_changed.Text = "Changed";
            // 
            // m_filter
            // 
            this.m_filter.Items.AddRange(new object[] {
            "*",
            "*.cpp",
            "*.h"});
            this.m_filter.Location = new System.Drawing.Point(16, 96);
            this.m_filter.Name = "m_filter";
            this.m_filter.Size = new System.Drawing.Size(152, 21);
            this.m_filter.TabIndex = 28;
            this.m_filter.Text = "*";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.mStopButton);
            this.groupBox2.Controls.Add(this.mStartButton);
            this.groupBox2.Controls.Add(this.ExitButton);
            this.groupBox2.Controls.Add(this.btnSaveLog);
            this.groupBox2.Location = new System.Drawing.Point(8, 296);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(448, 88);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Controls";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.lblCreated);
            this.groupBox3.Controls.Add(this.lblDeleted);
            this.groupBox3.Controls.Add(this.lblRenamed);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.lblChanged);
            this.groupBox3.Location = new System.Drawing.Point(232, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(216, 88);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Counters";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "Folder Listener Utility";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.DoubleClick += new System.EventHandler(this.notifyIcon1_DoubleClick);
            this.notifyIcon1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDown);
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1,
            this.menuItem8,
            this.menuItem2});
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem3,
            this.menuItem4,
            this.menuItem6,
            this.menuItem5});
            this.menuItem1.Text = "Controls";
            this.menuItem1.Visible = false;
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 0;
            this.menuItem3.Text = "Start";
            this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
            // 
            // menuItem4
            // 
            this.menuItem4.Index = 1;
            this.menuItem4.Text = "Stop";
            // 
            // menuItem6
            // 
            this.menuItem6.Index = 2;
            this.menuItem6.Text = "Save Log";
            // 
            // menuItem5
            // 
            this.menuItem5.Index = 3;
            this.menuItem5.Text = "Exit";
            // 
            // menuItem8
            // 
            this.menuItem8.Index = 1;
            this.menuItem8.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem9,
            this.menuItem10,
            this.menuItem11});
            this.menuItem8.Text = "Tools";
            // 
            // menuItem9
            // 
            this.menuItem9.Index = 0;
            this.menuItem9.Text = "Send Suggestion";
            this.menuItem9.Click += new System.EventHandler(this.menuItem9_Click);
            // 
            // menuItem10
            // 
            this.menuItem10.Index = 1;
            this.menuItem10.Text = "Send Feed Back";
            this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
            // 
            // menuItem11
            // 
            this.menuItem11.Index = 2;
            this.menuItem11.Text = "Report Bug ";
            this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click);
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 2;
            this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem7,
            this.menuItem12});
            this.menuItem2.Text = "Help";
            // 
            // menuItem7
            // 
            this.menuItem7.Index = 0;
            this.menuItem7.Text = "Help Doc";
            this.menuItem7.Visible = false;
            // 
            // menuItem12
            // 
            this.menuItem12.Index = 1;
            this.menuItem12.Text = "About";
            this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(464, 389);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.m_starting_path);
            this.Controls.Add(this.btnFolderBrowse);
            this.Controls.Add(this.label1);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FolderListener";
            this.StyleChanged += new System.EventHandler(this.Form1_StyleChanged);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabCreatedFiles.ResumeLayout(false);
            this.tabChangedFiles.ResumeLayout(false);
            this.tabDeletedFiles.ResumeLayout(false);
            this.tabRenameFiles.ResumeLayout(false);
            this.ExcludedFiles.ResumeLayout(false);
            this.txtSettings.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		//-----------------------------------------------------------------------
		private void ExitButtonClick(object sender, System.EventArgs e)
		{
			Application.Exit();
		}
		//-----------------------------------------------------------------------
		private void StopButtonClick(object sender, System.EventArgs e)
		{
			watcher.EnableRaisingEvents = false;		//Stop looking
		}
		//---------------------------------------------------------------------
		//This routine fills in the FileWatcher instance with parameters. It checks
		//the CheckBoxes to see what files to report on and what routines to use
		//to handle the events. Then it enables raising events, allowing
		//file change notification.
		private void StartButtonClick(object sender, System.EventArgs e)
		{
			
			if (watcher.EnableRaisingEvents == true) 
			{
				MessageBeep(100);
				return;
			}
			
			 m_textFilters=txtTextFilter.Text.Split(';');// Reset Text Filters
			

			// Set Control Status
			mStartButton.Enabled=false;
			mStopButton.Enabled=true;
			groupBox1.Enabled=false;
			btnSaveLog.Enabled=false;

			lstCreatedFiles.Items.Clear();
			lstChangedFiles.Items.Clear();
			lstRenameFiles.Items.Clear();
			lstDeletedFiles.Items.Clear();
			// Clear Lables
			lblCreated.Text="";
			lblChanged.Text="";
			lblDeleted.Text="";
			lblRenamed.Text="";
			
			btnFolderBrowse.Enabled=false;
			//btnBaseFolderBrowse.Enabled=false;
			//Start Timer  to enable Forml Caption Blinking
			timer1.Start();
			// Set Task bar Icon Text
			notifyIcon1.Text="Listning";
			




		
			watcher.Path   = m_starting_path.Text;
			watcher.Filter = m_filter.Text;
			watcher.NotifyFilter = 
				NotifyFilters.FileName
				//| NotifyFilters.Attributes
				//| NotifyFilters.LastAccess 
				| NotifyFilters.LastWrite
				//| NotifyFilters.Security 
				| NotifyFilters.Size;
				//| NotifyFilters.CreationTime;
			if (cb_changed.Checked == true)
				watcher.Changed += new FileSystemEventHandler(OnFileEvent);
			else watcher.Changed -= new FileSystemEventHandler(OnFileEvent);

			if (cb_created.Checked == true)
				watcher.Created += new FileSystemEventHandler(OnFileEvent);
			else watcher.Created -= new FileSystemEventHandler(OnFileEvent);

			if (cb_deleted.Checked == true)
				watcher.Deleted += new FileSystemEventHandler(OnFileEvent);
			else watcher.Deleted -= new FileSystemEventHandler(OnFileEvent);

			if (cb_renamed.Checked == true)
				watcher.Renamed += new RenamedEventHandler(OnRenameEvent);
			else watcher.Renamed -= new RenamedEventHandler(OnRenameEvent);

			if (cb_subdirectory.Checked == true)
				watcher.IncludeSubdirectories = true;
			else watcher.IncludeSubdirectories = false;

			watcher.EnableRaisingEvents = true;
		}
		//-----------------------------------------------------------------------
		public void OnFileEvent(object source, FileSystemEventArgs fsea) 
		{
			
			DateTime dt = new DateTime();
			dt = System.DateTime.UtcNow;
			//string txtFileChange= fsea.ChangeType.ToString()+" "+fsea.FullPath +" "+dt.ToLocalTime();
			string txtFileChange= fsea.FullPath ;
            Control.CheckForIllegalCrossThreadCalls = false; //See http://geekswithblogs.net/skogensblog/archive/2006/08/28/89541.aspx
	
			//Return if file path contains exclude String
			if( txtTextFilter.Text!="")// Filter List Not Empty
			{
				for (int i=0;i<m_textFilters.Length;i++)
				{
					if (txtFileChange.IndexOf(m_textFilters[i])>0)
					{
						return;
					}
				}
				
			}
			// Return if file is in Excluded list
			if( lstExclude.Items.Contains( txtFileChange)==true)
			{
				return;
			}
			//TO DO Bypass Multiple Change event - To Be implemented in Ver 2
			String chType=fsea.ChangeType.ToString();
			if(chType=="Created")
			{
				//Filter duplicate Entry
				if ((lstCreatedFiles.Items.Contains( txtFileChange)!=true))
				{
					lstCreatedFiles.Items.Add(txtFileChange);
					lstCreatedFiles.TopIndex=lstCreatedFiles.Items.Count-1;
					lblCreated.Text=lstCreatedFiles.Items.Count.ToString();
				}

			}
	
			if(chType=="Changed")
			{
				// Chenge Event is also fired when we create a file we need to by pass it 
				// Do not add change event if there is an entry in Creatd file list 
				if ((lstCreatedFiles.Items.Contains( txtFileChange)!=true))
				{
					//Only One change should be recored for a  watch session
					//if already a entry is made bypass the second one 
					if ((lstChangedFiles.Items.Contains( txtFileChange)!=true))
					{
						lstChangedFiles.Items.Add(txtFileChange);
						lstChangedFiles.TopIndex=lstChangedFiles.Items.Count-1;
						lblChanged.Text=lstChangedFiles.Items.Count.ToString();
					}
				}
		

			}
			if(chType=="Deleted")
			{
				lstDeletedFiles.Items.Add(txtFileChange);
				lstDeletedFiles.TopIndex=lstDeletedFiles.Items.Count-1;
				lblDeleted.Text=lstDeletedFiles.Items.Count.ToString();

			}
	
			//if ((lstCreatedFiles.Items.Contains( txtChange)!=true))
			//{
			//TO Do if create Event for file is fired then Change Event must be avoided-To Be implemented in Ver 2
		
		
			//}

            Control.CheckForIllegalCrossThreadCalls = true;
		}
    //  private delegate int addDelegate(object o);

      
        
		//----------------------------------------------------------------------
		public  void OnRenameEvent(Object source, RenamedEventArgs rea) 
		{
			DateTime dt = new DateTime();
			dt = System.DateTime.UtcNow;
			string txtChangeR=  rea.FullPath +" << " + rea.OldFullPath ;
			//lstCreatedFiles.Items.Add(txtChangeR);
			//TO DO Bypass Multiple Change event - fired after rename To Be implemented in Ver 2
	
			//if ((lstCreatedFiles.FindString( rea.OldFullPath)>0))
			//{

          //  


        /*    if (lstRenameFiles.InvokeRequired)
          {
              lstRenameFiles.Invoke(new addDelegate(lstRenameFiles.Items.Add), txtChangeR);
              lblRenamed.Invoke(new setPropertyDeligate(this.SetControlProperty), lblRenamed.Text, lstRenameFiles.Items.Count.ToString());
          }
          else
          {
              lstRenameFiles.Items.Add(txtChangeR);
              lblRenamed.Text = lstRenameFiles.Items.Count.ToString();
          }

            */

            Control.CheckForIllegalCrossThreadCalls = false; //See http://geekswithblogs.net/skogensblog/archive/2006/08/28/89541.aspx

			lstRenameFiles.Items.Add(txtChangeR);
			lblRenamed.Text= lstRenameFiles.Items.Count.ToString();
            Control.CheckForIllegalCrossThreadCalls = true; 
			
            
            //}
	
	

		}
     
		//------------------------------------------------------------------
		private void AboutButtonClick(object sender, System.EventArgs e)
		{
			MessageBox(0,"Folder Change Listner Utility" ,"About Application",0);
		}

		private void btnFolderBrowse_Click(object sender, System.EventArgs e)
		{
			folderBrowse.ShowDialog();
			if ("" != folderBrowse.SelectedPath)
			{
				m_starting_path.Text = folderBrowse.SelectedPath;

			}
		}

		private void btnSaveLog_Click(object sender, System.EventArgs e)
		{
			if ((lstCreatedFiles.Items.Count>0 || lstChangedFiles.Items.Count>0|| lstDeletedFiles.Items.Count>0|| lstRenameFiles.Items.Count>0)) 
			{
				// Disable button
				btnSaveLog.Text="Saving...";
				btnSaveLog.Enabled=false;
					saveFileDialog1.ShowDialog();
				if (saveFileDialog1.FileName!="")
				{


					TextWriter tw = new StreamWriter(saveFileDialog1.FileName);
					tw.WriteLine("//Created Files ---------------------------------");
					for (int i=0; i<lstCreatedFiles.Items.Count;i++ )
					{ // write a line of text to the file
						tw.WriteLine(lstCreatedFiles.Items[i]);

					}
					tw.WriteLine("//Changed Files ---------------------------------");
					for (int i=0; i<lstChangedFiles.Items.Count;i++ )
					{ // write a line of text to the file
						tw.WriteLine(lstChangedFiles.Items[i]);

					}
					tw.WriteLine("//Deleted Files ---------------------------------");
					for (int i=0; i<lstDeletedFiles.Items.Count;i++ )
					{ // write a line of text to the file
						tw.WriteLine(lstDeletedFiles.Items[i]);

					}
					tw.WriteLine("//Rename Files ---------------------------------");
					for (int i=0; i<lstRenameFiles.Items.Count;i++ )
					{ // write a line of text to the file
						tw.WriteLine(lstRenameFiles.Items[i]);

					}

					// close the stream
					tw.Close();
				}
				// Enable Button
				btnSaveLog.Text="Save Log";
				btnSaveLog.Enabled=true;
				MessageBox(0,"Log Saved Sucessfully ","Action Info",0);
			}
			else
			{
				MessageBox(0, "All File Lists  are empty nothing to  save", "Save Operation Fail", 0);
			}

		}

		private void mStopButton_Click(object sender, System.EventArgs e)
		{
			watcher.EnableRaisingEvents = false;
			mStartButton.Enabled=true;
			mStopButton.Enabled=false;
			groupBox1.Enabled=true;
			btnSaveLog.Enabled=true;

			
			btnFolderBrowse.Enabled=true;
			//btnBaseFolderBrowse.Enabled=true;
			//Start Timer  to enable Forml Caption Blinking
			timer1.Stop();
			Form1.ActiveForm.Text="Folder Listener";
			// Set Task bar Icon Text
			notifyIcon1.Text="Folder Listener Utility";


			
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{	// Disable text boxes having paths
			m_starting_path.Enabled=false;
			////txtBasePath.Enabled=false;
			
			// Load Text filter
			if(File.Exists("FolderListnerSettings.txt"))
			{
				StreamReader re = File.OpenText("FolderListnerSettings.txt");
				txtTextFilter.Text= re.ReadLine();// Text Filters
				m_starting_path.Text=re.ReadLine();// Watch Folder Path
				//txtBasePath.Text=re.ReadLine();//Base folder path
				m_filter.Text=re.ReadLine();// File Type filter
				re.Close();

			}
			
		}

		private void listBox1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void btnLoadExcludeFile_Click(object sender, System.EventArgs e)
		{
			
		}

		private void btnClearList_Click(object sender, System.EventArgs e)

		{
			lstExclude.Items.Clear();
		
		}

		private void btnBaseFolderBrowse_Click(object sender, System.EventArgs e)
		{
			folderBrowse.ShowDialog();
			if ("" != folderBrowse.SelectedPath)
			{
			
				//txtBasePath.Text = folderBrowse.SelectedPath;

			}
		}

		private void lstChangedFiles_DoubleClick(object sender, System.EventArgs e)
		{
			
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			
		}

		
		private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			// Save Text Filters 
			TextWriter tw = new StreamWriter("FolderListnerSettings.txt");
			tw.WriteLine(txtTextFilter.Text);// Text Filters
			tw.WriteLine(m_starting_path.Text);// Watch Folder Path
			//tw.WriteLine(txtBasePath.Text);//Base folder path
			tw.WriteLine(m_filter.Text);// File Type filter
			tw.Close();

			//MessageBox(0,"","",0);

            notifyIcon1.Dispose();
		}

		private void lstDeletedFiles_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void lstChangedFiles_DoubleClick_1(object sender, System.EventArgs e)
		{
		
			if (lstChangedFiles.SelectedItem.ToString()!=null)
			{
				
				
				
				string txtFileChanged=lstChangedFiles.SelectedItem.ToString();
				
				// Base Folder path +(file Path withoput Init Path)
			//	string txtFileOriginal=(//txtBasePath.Text)+  txtFileChanged.Substring(m_starting_path.Text.Length);

				//MessageBox(0,txtFileOriginal,"",0);
				//string cmdLine=" "+txtFileOriginal+" "+txtFileChanged;
				string executable="windiff.exe";
				
			//	System.Diagnostics.Process.Start(executable ,cmdLine );


			}
			
		}

		private void btnLoadExcludeFile_Click_1(object sender, System.EventArgs e)
		{
			lstExclude.Items.Clear();
			String txtBtnLabel= btnLoadExcludeFile.Text;
			btnLoadExcludeFile.Text="Loading...";
			btnLoadExcludeFile.Enabled=false;

            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.ShowDialog();
            if (fdlg.FileName=="")
	        {
		         return;
	        }
            string txtFilePath =fdlg.FileName;//"ExFileList.txt";// Contains the list of excluded files 
			

			StreamReader re = File.OpenText(txtFilePath);
			string input = null;
			while ((input = re.ReadLine()) != null)
			{
				lstExclude.Items.Add(m_starting_path.Text+"\\"+ input);
			}
			re.Close();

			btnLoadExcludeFile.Text=txtBtnLabel;
			
			btnLoadExcludeFile.Enabled=true;

		}

		private void btnClearList_Click_1(object sender, System.EventArgs e)
		{
			lstExclude.Items.Clear();
		
		}

		private void lstChangedFiles_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void groupBox3_Enter(object sender, System.EventArgs e)
		{
			
		}

		private void notifyIcon1_DoubleClick(object sender, System.EventArgs e)
		{
			this.ShowInTaskbar = true;
			Show();
			this.WindowState = FormWindowState.Normal;
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			
			
			if ((this.WindowState == FormWindowState.Minimized )&& Form1.ActiveForm==this)
			
			{
				if ((this.ShowInTaskbar == true))
				{
					this.ShowInTaskbar = false;
					//timer1.Stop();
				}
				else
				{
					this.ShowInTaskbar = true;				
					//timer1.Start();
				}
			}

		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			// Handle timer evnets only when if window not minimized
			//if (!(this.WindowState == FormWindowState.Minimized)&&Form1.ActiveForm==this)
			{
				
				if (this.FindForm().Text=="Listening...")
				{
					this.FindForm().Text="";//Folder Listener";
					
				
				}
				else
				{
					this.FindForm().Text="Listening...";
					
				}
			}

 
		}

		private void notifyIcon1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
		
		}

		private void menuItem9_Click(object sender, System.EventArgs e)
		{
			System.Diagnostics.Process.Start("mailto:ashwini47@yahoo.co.in?subject=Folder Listener/Suggestion");

		}

		private void menuItem10_Click(object sender, System.EventArgs e)
		{
            System.Diagnostics.Process.Start("mailto:ashwini47@yahoo.co.in?subject=Folder Listener/Feedback");
		}

		private void menuItem11_Click(object sender, System.EventArgs e)
		{
            System.Diagnostics.Process.Start("mailto:ashwini47@yahoo.co.in?subject=Folder Listener/Bug   ");
		}

		private void menuItem12_Click(object sender, System.EventArgs e)
		{
			MessageBox(0,"Folder Listener Ver 1.0 " ,"About",0);
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			//btnClearList_Click_1(null,null);
		}

		private void Form1_StyleChanged(object sender, System.EventArgs e)
		{
			
		}

		private void Form1_Activated(object sender, System.EventArgs e)
		{
			if (mStartButton.Enabled==false)
			{
				timer1.Start();

			}
		}

		
		/// <summary>
		/// indicates that weather form caption is changed or not  Used only in time event to show the listing Status 
		/// </summary>
		public bool FormTextStatus
		{
			get
			{
				return true;
			}
			set
			{
			}
		}

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
		//--------------------------------------------------------------------
	} //end class

} //end Namespace
